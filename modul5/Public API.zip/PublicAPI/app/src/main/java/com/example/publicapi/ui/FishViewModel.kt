package com.example.publicapi.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.publicapi.network.FishApi
import com.example.publicapi.network.FishItems
import kotlinx.coroutines.launch

enum class FishApiStatus { LOADING, ERROR, DONE}

class FishViewModel: ViewModel() {
    private val _status = MutableLiveData<FishApiStatus>()
    val status: LiveData<FishApiStatus> = _status

    private val _Fishes = MutableLiveData<List<FishItems>?> ()
    val Fishes: MutableLiveData<List<FishItems>?> = _Fishes

    private val _Fish = MutableLiveData<FishItems>()
    val Fish: LiveData<FishItems> = _Fish

    fun getFishList() {
        viewModelScope.launch {
            _status.value = FishApiStatus.LOADING
            try {
                _Fishes.value = FishApi.retrofitServiceApi.getFish().results
                _status.value = FishApiStatus.DONE
            } catch (e: Exception) {
                _Fishes.value = listOf()
                _status.value = FishApiStatus.ERROR
            }
        }
    }

    fun onFishClicked(Fish: FishItems) {
        _Fish.value = Fish
    }
}