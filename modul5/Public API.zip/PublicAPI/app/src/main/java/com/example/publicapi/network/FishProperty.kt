package com.example.publicapi.network

data class FishProperty (
    val results : List<FishItems>? = null,
    )

data class FishItems (
    val speciesName: String? = null,
    val scientificName: String? = null,
    val image: String? = null,
    val aliases: String? = null,
    val status: String? = null
    )