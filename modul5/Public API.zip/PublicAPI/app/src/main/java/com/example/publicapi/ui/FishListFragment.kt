package com.example.publicapi.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.publicapi.R
import com.example.publicapi.databinding.FragmentFishListBinding

class FishListFragment: Fragment() {
    private val viewModel: FishViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentFishListBinding.inflate(inflater)
        viewModel.getFishList()
        binding.lifecycleOwner = this
        binding.viewModel = viewModel
        binding.recyclerView.adapter = FishListAdapter(FishListener { fish ->
            viewModel.onFishClicked(fish)
            findNavController()
                .navigate(R.id.action_FishListFragment_to_FishDetailFragment)
        })
        (activity as AppCompatActivity).supportActionBar?.title = "The Fishes Profiles"

        return binding.root
    }
}