package com.example.publicapi.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.publicapi.databinding.ListViewItemBinding
import com.example.publicapi.network.FishItems

class FishListAdapter ( val clickListener: FishListener) :
    ListAdapter<FishItems, FishListAdapter.FishViewHolder>(DiffCallback) {

    class FishViewHolder(
        var binding: ListViewItemBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(clickListener: FishListener, Fish: FishItems) {
            binding.fish = Fish
            binding.clickListener = clickListener
            binding.executePendingBindings()
        }
    }

    companion object DiffCallback: DiffUtil.ItemCallback<FishItems>() {
        override fun areItemsTheSame(oldItem: FishItems, newItem: FishItems): Boolean {
            return oldItem.speciesName == newItem.speciesName
        }

        override fun areContentsTheSame(oldItem: FishItems, newItem: FishItems): Boolean {
            return oldItem.image == newItem.image
                    && oldItem.scientificName == newItem.scientificName
                    && oldItem.aliases == newItem.aliases
                    && oldItem.status == newItem.status
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FishViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return FishViewHolder(
            ListViewItemBinding.inflate(layoutInflater, parent, false)
        )
    }
    override fun onBindViewHolder(holder: FishViewHolder, position: Int) {
        val Fish = getItem(position)
        holder.bind(clickListener, Fish)
    }
}

class FishListener(val clickListener: (Fish: FishItems) -> Unit) {
    fun onClick(Fish: FishItems) = clickListener(Fish)
}